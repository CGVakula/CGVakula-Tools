import bpy
import os

from os.path import join, dirname, realpath


cgvt_icons_collection = {}
cgvt_icons_loaded = False

icons_dir = join(dirname(realpath(__file__)))
image_size = (32, 32)


# Переменная для вычисленного среднего значения при выделении объектов

# cgvt_step_value_y = None

# def step_value(context):
#     global cgvt_step_value_y

#     selected_objects = context.selected_objects
#     array_y = []
#     for so in selected_objects:
#         array_y.append(so.location[1])
#     min_y = min(array_y)
#     max_y = max(array_y)
    
#     dist_between = abs(min_y - max_y)
#     cgvt_step_value_y = dist_between / (len(selected_objects) - 1)

    # print(cgvt_step_value_y)


# Метод для выборки мешей из всех объектов

def mesh_objects(context):
    return list(filter(lambda obj: obj.type == "MESH" and obj.mode == "OBJECT", context.selected_objects))

# Иконки

def load_icons():
    global cgvt_icons_collection
    global cgvt_icons_loaded

    if cgvt_icons_loaded:
        return cgvt_icons_collection["main"]
    custom_icons = bpy.utils.previews.new()

    icons_dir = join(dirname(realpath(__file__)), 'icons')


    for f in os.listdir(icons_dir):
        f = f.split('.png')
        if len(f) == 2:
            custom_icons.load(f[0], join(icons_dir, f[0] + '.png'), 'IMAGE')


    cgvt_icons_collection["main"] = custom_icons
    cgvt_icons_loaded = True

    return cgvt_icons_collection["main"]


def clear_icons():
    global cgvt_icons_loaded
    for icon in cgvt_icons_collection.values():
        bpy.utils.previews.remove(icon)
    cgvt_icons_collection.clear()
    cgvt_icons_loaded = False

# метод для получения дефолтного значения

def get_value_or_default(holder, prop_name):
    value = getattr(holder, prop_name)
    if value is not None:
        return value
    prop = holder.bl_rna.properties[prop_name]
    if prop.default_array:
        return [v for v in prop.default_array]
    else:
        return prop.default