'''
Copyright © 2024
Created by CGVakula (Sergey Vakulenko)
https://www.artstation.com/cgvakula

Blog - https://t.me/cgvakula

Email: 

'''
import bpy
from . import m_prefs
from .panels import m_box_aligners


if bpy.app.version < (2, 93, 0):
    raise Exception("This addon requires Blender 2.93 or later")

bl_info = {
    "name": "CGVakula Tools",
    "author": "CGVakula",
    "version": (0, 2, 7),
    "blender": (3, 6, 5),
    "location": "View3D -> N-Panel -> CGVT",
    "description": "CGVakula Tools",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

modules = (
    m_prefs,
    m_box_aligners
)

addon_keymaps = []

def register():
    m_prefs.cgvt_version = bl_info['version']
    
    # import importlib
    
    for m in modules:
        # importlib.reload(m)
        m.register()

    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name="Object Mode")

    kmi = km.keymap_items.new("object.cgvt_bounding_on", "P", "PRESS", ctrl=False, shift=False)
    addon_keymaps.append((km, kmi))   


def unregister():
    for m in modules:
        m.unregister()

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()    
    