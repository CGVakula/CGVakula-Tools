# Модуль с панелью и кнопками выравнивания
import os

from bpy.types import Panel
from bpy.utils import register_class, unregister_class


from ..operators import cgvt_align_to_y, cgvt_align_to_floor, cgvt_align_to_ground, cgvt_align_to_centr_world, cgvt_align_to_centr_mesh, cgvt_distribute
from ..helpers import *


class OBJECT_PT_CGVT_Aligners(Panel):
    bl_idname = "UI_PT_Aligners"
    bl_label = "Aligners"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    # bl_category = __package__
    bl_parent_id = "UI_PT_CGVT_Main"
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.cgvt_aligners

        icons = load_icons()
        a2ground_ico = icons.get("align_to_ground")

        box = layout.box()
        box.label(text='Aligners')
        box.scale_y = 0.5

        col = layout.column(align=True)
        col.scale_y = 1.5
        col.scale_x = 1.2
        # Pivot to Ground
        row = col.row(align=True)
        row.operator('object.cgvt_bounding_on',
                     text='Pivot to Ground Mesh', icon_value=a2ground_ico.icon_id)
        # Кнопка URL
        row.operator("wm.url_open", text="",
                     icon="URL").url = "https://www.youtube.com/@cgvakula"
        # Pivot to Center Mesh
        row2 = col.row(align=True)
        row2.operator('object.cgvt_pivot_to_center_mesh',
                      text='Pivot to Center Mesh')
        # Mesh to Z=0
        row3 = col.row(align=True)
        row3.operator('object.cgvt_on_floor', text='Mesh to Z=0')
        # Mesh to Y=0
        row4 = col.row(align=True)
        row4.operator('object.cgvt_align_on_y', text='Mesh to Y=0')
        # Mesh to XYZ=0
        row5 = col.row(align=True)
        row5.operator('object.cgvt_on_center_world', text='Mesh to XYZ=0')

        box = layout.box()
        box.label(text='Expand for Texturing')
        box.scale_y = 0.5

        # Distribute
        col = layout.column(align=True)
        col.scale_y = 1.5
        col.operator("object.cgvt_distribute_y", text="Expand by Y")
        col = layout.column(align=True)
        col.prop(settings, "step_auto_calc", text="Auto value by Y axis")
        col = layout.column(align=True)
        col.prop(settings, "current_step_value", text="Step")


# classes = (
#     OBJECT_PT_CGVT_Aligners
# )


modules = (
    cgvt_align_to_floor,
    cgvt_align_to_ground,
    cgvt_align_to_centr_world,
    cgvt_align_to_centr_mesh,
    cgvt_distribute,
    cgvt_align_to_y
)


def register():
    register_class(OBJECT_PT_CGVT_Aligners)
    
    # for cls in classes:
    #     register_class(cls)
    for m in modules:
        m.register()


def unregister():
    unregister_class(OBJECT_PT_CGVT_Aligners)
    # for cls in reversed(classes):
    #     unregister_class(cls)
    for m in modules:
        m.unregister()
