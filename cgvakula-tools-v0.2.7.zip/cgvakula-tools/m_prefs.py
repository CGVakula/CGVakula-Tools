# Модуль с основными настройками и главной панелью
import os
import bpy

from bpy.types import Panel, AddonPreferences, PropertyGroup
from bpy.utils import register_class, unregister_class
from bpy.props import StringProperty, BoolProperty, PointerProperty, FloatProperty

cgvt_version = (0, 0, 0)  # is set from __init__

# def msgbus_callback():
#     if len(bpy.context.selected_objects) > 1:
#         step_value_update(bpy.context)
#         print(bpy.context.scene.cgvt_aligners["current_step_value"])
        
# def subscribe_to_obj(): 
#     bpy.msgbus.subscribe_rna(
#         key=(bpy.types.LayerObjects, 'active'),
#         owner=bpy,
#         args=(),
#         notify=msgbus_callback
#     )

class CGVT_AlignersSettings(PropertyGroup):
    # Чекбокс
    current_step_value: FloatProperty(
        name="Current step value",
        default=0.00,
        min=0.00
    ) # type: ignore

    step_auto_calc: BoolProperty(
        name="Fixed value",
        description="Disable to avoid auto calculation",
        default=True
    )  # type: ignore




class CGVT_AddonPreferences(AddonPreferences):
    bl_idname = __package__
    version: StringProperty(name="", default="") # type: ignore
class UI_CGVakula_Main(Panel):
    bl_idname = "UI_PT_CGVT_Main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    # bl_category = __package__
    bl_category = 'CGVT'
    bl_label = 'CGVakula Tools'
    bl_description = 'CGVT Main Panel'

    def draw_header_preset(self, context):
        layout = self.layout
        layout.emboss = 'NONE'
        row = layout.row(align=True)
        row.label(text="%s" % bpy.context.preferences.addons[__package__].preferences.version)
        # row.operator("wm.url_open", text="", icon="URL").url = "https://www.artstation.com/cgvakula"
        
    def draw(self, context):
        layout = self.layout

classes = (
    CGVT_AlignersSettings,
    CGVT_AddonPreferences,
    UI_CGVakula_Main
)


# def step_getter(self):
#     collection = bpy.data.collections["CGVT_Collection"]
    
#     if getattr(bpy.context.scene.cgvt_aligners, "step_auto_calc", True) and find_step_value():
#         collection["step_value"] = find_step_value()
    
#     return collection["step_value"]
    

# def step_setter(self, value):
#     collection = bpy.data.collections["CGVT_Collection"]
#     collection["step_value"] = value

def register():
    # register_class(UI_CGVakula_Main)

    for cls in classes:
        register_class(cls)
    
    v = "v" + str(cgvt_version[0]) + "." + str(cgvt_version[1]) + "." + str(cgvt_version[2])
    bpy.context.preferences.addons[__package__].preferences.version = v

    bpy.types.Scene.cgvt_aligners = PointerProperty(type=CGVT_AlignersSettings)
    
    # subscribe_to_obj()
        
def unregister():
    # unregister_class(UI_CGVakula_Main)
    for cls in reversed(classes):
        unregister_class(cls)
    
    del bpy.types.Scene.cgvt_aligners


