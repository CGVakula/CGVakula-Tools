from typing import Set
import bpy
from bpy.types import Context, Event, Operator
from ..helpers import *


cgvt_distribute_selected_obj = []
class OBJECT_OT_Distribute_Y(Operator):
    bl_label = "Y_Distribute"
    bl_idname = "object.cgvt_distribute_y"
    bl_description = "Distribute objects by Y"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"REGISTER", "UNDO"}
    

    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 1

    def execute(self, context):
        step_auto_calc = get_value_or_default(context.scene.cgvt_aligners, "step_auto_calc")
        if not step_auto_calc:
            return self.distribute(context)
            
        
        global cgvt_distribute_selected_obj
        current_selected_obj = context.selected_objects
        if current_selected_obj is cgvt_distribute_selected_obj:
            return self.distribute(context)
            
        cgvt_distribute_selected_obj = current_selected_obj
        self.step_value_update(context)
        return self.distribute(context)
    
        
    
    #////////////////////////////////////////
    def distribute(self, context):
        selected_objects = context.selected_objects
        ydict = {}
        for so in selected_objects:
            ydict[so] = so.location[1]
        sorteddict = sorted(ydict.items(), key=lambda obj: obj[1])
        # distanceY = abs(sorteddict[0][1] - sorteddict[-1][1])
        stepY = get_value_or_default(context.scene.cgvt_aligners, "current_step_value")
        for la in range(len(sorteddict)):
            if la != 0:
                sorteddict[la][0].location = (sorteddict[la][0].location[0], (sorteddict[0][1]) + stepY * la, sorteddict[la][0].location[2])
        return {'FINISHED'}    
    # ///////////////////////////////////////
    
    def find_step_value(self, context):
        selected_objects = context.selected_objects
        if len(selected_objects) < 3:
            return None 
        
        array_y = []
        for so in selected_objects:
            array_y.append(so.location[1])
        min_y = min(array_y)
        max_y = max(array_y)
        
        dist_between = abs(min_y - max_y)
        print(dist_between, 'find_step_value')
        return dist_between / (len(selected_objects) - 1)


    def step_value_update(self, context):
        new_step_value = self.find_step_value(context)
        if new_step_value is not None:
            bpy.context.scene.cgvt_aligners["current_step_value"] = new_step_value
    
    # ///////////////////////////////////////


classes = (
    OBJECT_OT_Distribute_Y,
)


def register():
    # bpy.types.Scene.cgvt_calculated_step = 0.0
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    # del bpy.types.Scene.cgvt_calculated_step
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
        