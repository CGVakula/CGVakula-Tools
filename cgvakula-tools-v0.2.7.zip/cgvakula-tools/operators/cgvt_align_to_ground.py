# Операторы

import bpy
import copy
from bpy.types import Operator
from bpy.utils import register_class, unregister_class

def ground_pivot_point(context):   
    # Получаем активный объект
    obj = context.active_object

    # Получаем bounding box объекта
    bbox = [obj.matrix_world @ v.co for v in obj.data.vertices]
    min_x = min(bbox, key=lambda v: v.x).x
    min_y = min(bbox, key=lambda v: v.y).y
    min_z = min(bbox, key=lambda v: v.z).z

    # Вычисляем центр между нижними точками
    center = (min_x + (max(v.x for v in bbox) - min_x) / 2,
            min_y + (max(v.y for v in bbox) - min_y) / 2,
            min_z)

    # Устанавливаем pivot point в центр
    current_location = copy.copy(context.scene.cursor.location)

    context.scene.cursor.location = center
    bpy.ops.object.origin_set(type="ORIGIN_CURSOR", center="MEDIAN")
    context.scene.cursor.location = current_location

    # Конец скрипта

def multi_ground_pivot_point():
    for obj in bpy.context.selected_objects:
        if obj.type != "MESH":
            print(f"Object {obj.name} is not a mesh. Skipping...")
            continue
    
        # Deselect all objects
        bpy.ops.object.select_all(action="DESELECT")
        
        # Select the current object
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

        ground_pivot_point(bpy.context)



class OBJECT_OT_Ground_pivot_point(Operator):
    bl_label = "CGVT"
    bl_idname = "object.cgvt_bounding_on"
    bl_description = "Align pivot point to bottom mesh"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.select_get() and obj.type == "MESH" and obj.mode == "OBJECT"
    
    def execute(self, context):
        objs = context.selected_objects
        if len(objs) > 1:
            multi_ground_pivot_point()
        else:
            ground_pivot_point(context)
        self.report({"INFO"}, "Pivot point grounded!")
        return {"FINISHED"}
    


def register():
    register_class(OBJECT_OT_Ground_pivot_point)
        
def unregister():
    unregister_class(OBJECT_OT_Ground_pivot_point)
    