import bpy
import copy
from bpy.types import Operator
from bpy.utils import register_class, unregister_class


def align_to_center_world(context):
    bpy.context.object.location[0] = 0
    bpy.context.object.location[1] = 0
    bpy.context.object.location[2] = 0

  # применяем то выравнивание для всех выделенных мешей  
def multi_align_to_center_world():
    for obj in bpy.context.selected_objects:
        if obj.type != "MESH":
            print(f"Object {obj.name} is not a mesh. Skipping...")
            continue
    
        # Deselect all objects
        bpy.ops.object.select_all(action="DESELECT")
        
        # Select the current object
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

        align_to_center_world(bpy.context)    

class OBJECT_OT_Center_World_Align(Operator):
    bl_label = "CGVT"
    bl_idname = "object.cgvt_on_center_world"
    bl_description = "Align Mesh to XYZ=0"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj and obj.select_get() and obj.type == "MESH" and obj.mode == "OBJECT"
    
    def execute(self, context):
        objs = context.selected_objects
        if len(objs) > 1:
            multi_align_to_center_world()
        else:
            align_to_center_world(context) 

        self.report({"INFO"}, "Mesh aligned to XYZ=0!")
        return {"FINISHED"}
    

def register():
    register_class(OBJECT_OT_Center_World_Align)
        
def unregister():
    unregister_class(OBJECT_OT_Center_World_Align)
    